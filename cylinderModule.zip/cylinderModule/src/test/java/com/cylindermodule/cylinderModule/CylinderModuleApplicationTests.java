package com.cylindermodule.cylinderModule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CylinderModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
