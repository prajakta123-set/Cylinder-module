package com.cylindermodule.cylinderModule.controller;



import java.util.List;

import com.cylindermodule.cylinderModule.model.Cylinder;
import com.cylindermodule.cylinderModule.service.CylinderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/cylinders")
public class CylinderController {

    @Autowired
    CylinderService cylinderService;

    @PostMapping("/add")
    public Cylinder addCylinder(@RequestBody Cylinder cylinder) {
        return cylinderService.addCylinder(cylinder);
    }

    @GetMapping("/all")
    public List<Cylinder> getAllCylinders() {
        return cylinderService.getAllCylinders();
    }

    @GetMapping("/{id}")
    public Cylinder getCylinderById(@PathVariable int id) {
        return cylinderService.getCylinderById(id);
    }

    @DeleteMapping("/{id}")
    public String deleteCylinder(@PathVariable int id) {
        cylinderService.deleteCylinder(id);
        return "Cylinder Deleted Successfully";
    }
}
