package com.cylindermodule.cylinderModule.service;


import java.util.*;

import com.cylindermodule.cylinderModule.model.Cylinder;
import com.cylindermodule.cylinderModule.repository.CylinderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CylinderService {

    @Autowired
    CylinderRepository cylinderRepo;

    public Cylinder addCylinder(Cylinder cylinder) {
        return cylinderRepo.save(cylinder);
    }

    public List<Cylinder> getAllCylinders() {
        return cylinderRepo.findAll();
    }

    public Cylinder getCylinderById(int id) {
        return cylinderRepo.findById(id).orElse(null);
    }

    public void deleteCylinder(int id) {
        cylinderRepo.deleteById(id);
    }
}
