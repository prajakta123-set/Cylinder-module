package com.cylindermodule.cylinderModule.repository;


import com.cylindermodule.cylinderModule.model.Cylinder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CylinderRepository extends JpaRepository<Cylinder, Integer> {

}
