package com.cylindermodule.cylinderModule.model;


import jakarta.persistence.*;
import java.util.Date;

@Entity
public class Cylinder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cylinderId;
    private String type;
    private float price;
    private String status; // Available, Booked, Out of Stock
    private Date lastRefillDate;
    private Date nextRefillDate;

    // Getters and Setters
    public int getCylinderId() {
        return cylinderId;
    }
    public void setCylinderId(int cylinderId) {
        this.cylinderId = cylinderId;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public float getPrice() {
        return price;
    }
    public void setPrice(float price) {
        this.price = price;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public Date getLastRefillDate() {
        return lastRefillDate;
    }
    public void setLastRefillDate(Date lastRefillDate) {
        this.lastRefillDate = lastRefillDate;
    }
    public Date getNextRefillDate() {
        return nextRefillDate;
    }
    public void setNextRefillDate(Date nextRefillDate) {
        this.nextRefillDate = nextRefillDate;
    }
}
